import json
import Leitura

nome_ficheiro = "dados.txt"

urls = Leitura.ler(nome_ficheiro)
print json.dumps(urls, indent=4, sort_keys=True)

