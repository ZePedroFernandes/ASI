import json
import Leitura
import Stats

nome_ficheiro = "dados.txt"

urls = Leitura.ler(nome_ficheiro)
print (json.dumps(urls, indent=4, sort_keys=True))

print("#"*80)

u,m = Stats.URLmaisVisitado(urls)
print ("A url %s foi a mais visitada com %d visitas" % (u,m))

print("#"*80)

mesmais = Stats.MESmaisVisitado(urls)
print (json.dumps(mesmais, indent=4, sort_keys=True))

print("#"*80)

ord = Stats.TIMEURLmaisVisitado(urls)
print (json.dumps(ord, indent=4, sort_keys=True))


