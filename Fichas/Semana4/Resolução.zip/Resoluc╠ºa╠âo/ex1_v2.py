import sys

PRECO_BASE = sys.stdin.readline().strip()
precoFinal="("+PRECO_BASE+"*23%)-10"
print(precoFinal)
precoFinal =  precoFinal.replace("%","/100+"+PRECO_BASE)
print(precoFinal)
print (eval(precoFinal))

