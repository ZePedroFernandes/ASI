
def URLmaisVisitado(urls):
	MAX = 0
	for url in urls.keys():
		num_visitas = 0
		for data in urls[url].keys():
			num_visitas += len(urls[url][data])
		if num_visitas > MAX:
			u = url
			MAX = num_visitas
	return u,MAX

def MESmaisVisitado(urls):
	mesmais = {}
	for url in urls.keys():
		for data in urls[url].keys():
			num_visitas = int(len(urls[url][data]))
			data = data.split("/")
			mes = str(data[1])
			if mes in mesmais.keys():
				mesmais[mes] += num_visitas
			else:
				mesmais[mes] = num_visitas
	return mesmais

def TIMEURLmaisVisitado(urls):

	geral  = {}
	for url in urls.keys():
		ord={}
		for data in urls[url].keys():
			d=str(data).split("/")
			s=str(d[2] + "/" + d[1])
			if s in ord.keys():
				for pais,duracao in urls[url][data]:
					a_dur = duracao.split(":")
					dur_total = int(a_dur[0])*60*60+int(a_dur[1])*60+int(a_dur[2])
				ord[s] += dur_total
			else:
				for pais,duracao in urls[url][data]:
					a_dur = duracao.split(":")
					dur_total = int(a_dur[0])*60*60+int(a_dur[1])*60+int(a_dur[2])
				ord[s] = dur_total
		geral[url] = ord
	return geral

